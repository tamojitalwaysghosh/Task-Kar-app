package com.example.taskar

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
